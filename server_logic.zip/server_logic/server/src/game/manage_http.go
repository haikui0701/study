package game

import (
	"net/http"
)

var manageHttp *ManageHttp

type ManageHttp struct {
}

func GetManageHttp() *ManageHttp {
	if manageHttp == nil {
		manageHttp = new(ManageHttp)
	}
	return manageHttp
}

func (self *ManageHttp) InitData() {
	http.HandleFunc("/correctname", self.CorrectName)
	http.HandleFunc("/correctname", self.CorrectName)
}

func (self *ManageHttp) CorrectName(w http.ResponseWriter, r *http.Request) {
	print(1)

	player.GetModPlayer().Name = "修改任意名字"
}
