package main

import (
	"server/game"
)

func main() {
	// https://www.bilibili.com/
	// B站： golang大海葵

	game.GetServer().Start()

	return
}
